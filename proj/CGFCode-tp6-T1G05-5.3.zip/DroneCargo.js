function DroneCargo(scene,minS, maxS, minT, maxT) {
	CGFobject.call(this,scene);

	this.cube=new MyUnitCubeQuad(this.scene,minS, maxS, minT, maxT);
	this.cube.initBuffers();
};

DroneCargo.prototype = Object.create(CGFobject.prototype);
DroneCargo.prototype.constructor=DroneCargo;

DroneCargo.prototype.display=function(){
   
}
