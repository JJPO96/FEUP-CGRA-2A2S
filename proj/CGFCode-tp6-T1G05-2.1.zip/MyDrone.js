function MyDrone(scene,speed,minS, maxS, minT, maxT) {
	CGFobject.call(this,scene);
	this.x = 5;
	this.y = 5;
	this.z = 5;
	this.ang = 0;
	this.body=new MyDroneBody(this.scene,minS, maxS, minT, maxT);
	this.body.initBuffers();
};

MyDrone.prototype = Object.create(CGFobject.prototype);
MyDrone.prototype.constructor=MyDrone;

MyDrone.prototype.display=function(){
	this.scene.pushMatrix();
		this.scene.translate(this.x,this.y,this.z);
		this.scene.rotate(this.ang,0,1,0);
		this.body.display();
	this.scene.popMatrix();
}

MyDrone.prototype.move = function (ind){
	if(ind == 0){ //a
		this.ang -= 0.25;
	} else if(ind == 1){ //w
		this.x += 0.25 * Math.sin(this.ang) * this.sp;
		this.z += 0.25 * Math.cos(this.ang) * this.sp;
	} else if(ind == 2){ //s
		this.x -= 0.25 * Math.sin(this.ang) * this.sp;
		this.z -= 0.25 * Math.cos(this.ang) * this.sp;
	} else if(ind == 3){ //d
		this.ang += 0.25;
	} else if(ind == 4){ //i
		this.y += 0.25;
	} else if(ind == 5){ //j
		this.y -= 0.25;
	}
}

MyDrone.prototype.updateSpeed = function(speed) {
	this.sp = speed;
};
