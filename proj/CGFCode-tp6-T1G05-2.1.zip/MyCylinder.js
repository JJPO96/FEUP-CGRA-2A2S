/**
 * MyCylinder
 * @constructor
 */
 function MyCylinder(scene, slices, stacks) {
 	CGFobject.call(this,scene);

	this.slices = slices;
	this.stacks = stacks;

 	this.initBuffers();
 };

 MyCylinder.prototype = Object.create(CGFobject.prototype);
 MyCylinder.prototype.constructor = MyCylinder;

 MyCylinder.prototype.initBuffers = function() {
 	/*
 	* TODO:
 	* Replace the following lines in order to build a prism with a **single mesh**.
 	*
 	* How can the vertices, indices and normals arrays be defined to
 	* build a prism with varying number of slices and stacks?
 	*/

 	this.vertices = [];

 	this.indices = [];

 	this.normals = [];

  this.texCoords = [];

	this.angle = Math.PI*2/this.slices;

	for (var j = 0; j <= this.stacks; j++) {
		for (var i = 0; i < this.slices; i++) {
		this.vertices.push(Math.cos(i*this.angle),Math.sin(i*this.angle),j/this.stacks);
		this.normals.push(Math.cos(i*this.angle),Math.sin(i*this.angle),0);
		}
	}

	for (var j = 0; j < this.stacks; j++) {
		for (var i = 0; i < this.slices; i++) {
			this.indices.push(this.slices*j+i,this.slices*j+i+1,this.slices*(j+1)+i);
			if (i != (this.slices - 1))
				this.indices.push(this.slices*(j+1)+i+1,this.slices*(j+1)+i,this.slices*j+i+1);
			else
				this.indices.push(this.slices*j,this.slices*j+i+1,this.slices*j+i);
		}
	}

  var tempS = 0;
  var tempT = 0;
  var dS = 1/this.slices;
  var dT = 1/this.stacks;

  for (var j = 0; j < this.stacks; j++) {
    for (var i = 0; i < this.slices; i++) {
      this.texCoords.push(tempT,tempS);
      tempS += dS;
    }
    tempS = 0;
    tempT += dT;
  }

	//this.normals.push(Math.cos(this.angle*(i-1)+this.angle/2),Math.sin(this.angle*(i-1)+this.angle/2),0);

 	this.primitiveType = this.scene.gl.TRIANGLES;
 	this.initGLBuffers();
 };
