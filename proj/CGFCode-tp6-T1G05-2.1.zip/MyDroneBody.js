/**
 * MyDroneBody
 * @param gl {WebGLRenderingContext}
 * @constructor
 */
function MyDroneBody(scene,minS, maxS, minT, maxT) {
	CGFobject.call(this,scene);

	this.minS = minS;
	this.minT = minT;
	this.maxS = maxS;
	this.maxT = maxT;

	this.initBuffers();
};

MyDroneBody.prototype = Object.create(CGFobject.prototype);
MyDroneBody.prototype.constructor=MyDroneBody;

MyDroneBody.prototype.initBuffers = function () {
	this.vertices = [
		0.5, 0.3, 0,
		-0.5, 0.3, 0,
		0, 0.3, 2
	];

	this.indices = [
			0, 1, 2,
			2, 1, 0
	];

	this.normals = [
		0,1,0,
		0,1,0,
		0,1,0,
		0,-1,0,
		0,-1,0,
		0,-1,0
	];
	this.primitiveType=this.scene.gl.TRIANGLES;
	this.initGLBuffers();
};
